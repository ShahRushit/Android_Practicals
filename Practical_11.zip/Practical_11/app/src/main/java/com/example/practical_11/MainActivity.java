package com.example.practical_11;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btn0,btnadd,btnsub,btnmul,btndiv,btneql,btnce;
    EditText etdisplay;

    float r1,r2;
    boolean one,two,three,four;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = (Button)findViewById(R.id.btn1);
        btn2 = (Button)findViewById(R.id.btn2);
        btn3 = (Button)findViewById(R.id.btn3);
        btn4 = (Button)findViewById(R.id.btn4);
        btn5 = (Button)findViewById(R.id.btn5);
        btn6 = (Button)findViewById(R.id.btn6);
        btn7 = (Button)findViewById(R.id.btn7);
        btn8 = (Button)findViewById(R.id.btn8);
        btn9 = (Button)findViewById(R.id.btn9);
        btn0 = (Button)findViewById(R.id.btn0);
        btnadd = (Button)findViewById(R.id.btnadd);
        btnsub = (Button)findViewById(R.id.btnsub);
        btnmul = (Button)findViewById(R.id.btnmul);
        btndiv = (Button)findViewById(R.id.btndiv);
        btneql = (Button)findViewById(R.id.btneql);
        btnce = (Button)findViewById(R.id.btnce);
        etdisplay = (EditText)findViewById(R.id.etdislay);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etdisplay.setText(etdisplay.getText()+"1");
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etdisplay.setText(etdisplay.getText()+"2");
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etdisplay.setText(etdisplay.getText()+"3");
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etdisplay.setText(etdisplay.getText()+"4");
            }
        });

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etdisplay.setText(etdisplay.getText()+"5");
            }
        });

        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etdisplay.setText(etdisplay.getText()+"6");
            }
        });

        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etdisplay.setText(etdisplay.getText()+"7");
            }
        });

        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etdisplay.setText(etdisplay.getText()+"8");
            }
        });

        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etdisplay.setText(etdisplay.getText()+"9");
            }
        });
        btn0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etdisplay.setText(etdisplay.getText()+"0");
            }
        });

        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etdisplay==null){
                    etdisplay.setText("");
                }
                else{
                    r1 = Float.parseFloat(etdisplay.getText()+"");
                    one = true;
                    etdisplay.setText(null);
                }
            }
        });

        btnsub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etdisplay==null){
                    etdisplay.setText("");
                }
                else{
                    r1 = Float.parseFloat(etdisplay.getText()+"");
                    two = true;
                    etdisplay.setText(null);
                }
            }
        });

        btnmul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etdisplay==null){
                    etdisplay.setText("");
                }
                else{
                    r1 = Float.parseFloat(etdisplay.getText()+"");
                    three = true;
                    etdisplay.setText(null);
                }
            }
        });

        btndiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etdisplay==null){
                    etdisplay.setText("");
                }
                else{
                    r1 = Float.parseFloat(etdisplay.getText()+"");
                    four = true;
                    etdisplay.setText(null);
                }
            }
        });

        btneql.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                r2 = Float.parseFloat(etdisplay.getText() + "");

                if(one == true)
                {
                    etdisplay.setText(r1 + r2 + "");
                    one = false;
                }
                if(two == true)
                {
                    etdisplay.setText(r1 - r2 + "");
                    two = false;
                }
                if(three == true)
                {
                    etdisplay.setText(r1 * r2 + "");
                    three = false;
                }
                if(four == true)
                {
                    etdisplay.setText(r1 / r2 + "");
                    four = false;
                }


            }
        });

//        btneql.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                r2 = Float.parseFloat(etdisplay.getText()+"");
//                float addans,subans,mulans,divans;
//                if (add == true) {
//                    addans = r1 + r2;
//                    etdisplay.setText(addans + "");
//                    add = false;
//                }
//
//                if (sub == true) {
//                    subans = r1 - r2;
//                    etdisplay.setText(subans + "");
//                    sub = false;
//                }
//
//                if (mul == true) {
//                    etdisplay.setText(r1 * r2 + "");
//                    mul = false;
//                }
//
//                if (div == true) {
//                    etdisplay.setText(r1 / r2 + "");
//                    div = false;
//                }
//            }
//        });
//
        btnce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etdisplay.setText("");
            }
        });
    }
}